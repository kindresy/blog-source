/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
/* 独立包专用兼容头：满足 libpldm bitfield 声明，不依赖 Linux 内核头。
 * 仅支持 GCC/Clang 提供的字节序宏，不自行猜测目标架构的字节序。
 */
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
#define __LITTLE_ENDIAN_BITFIELD
#elif __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#define __BIG_ENDIAN_BITFIELD
#else
#error Unsupported byte order
#endif
