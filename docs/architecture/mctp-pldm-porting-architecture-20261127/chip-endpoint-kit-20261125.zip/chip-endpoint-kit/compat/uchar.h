/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include <stdint.h>
/* 所选 libpldm Base 编译路径只需要这两个 C11 类型，不使用字符转换函数。
 * 为缺少 uchar.h 的 Xuantie newlib 提供类型，不声称实现完整 C11 uchar API。
 */
typedef uint_least16_t char16_t;
typedef uint_least32_t char32_t;
